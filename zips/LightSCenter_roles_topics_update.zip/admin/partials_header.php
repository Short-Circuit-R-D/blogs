<?php
/** @var string $pageTitle */
/** @var string $activeNav */
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Dashboard') ?> — Lighting CMS</title>
<link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="admin-shell">
  <aside class="admin-nav">
    <div class="admin-nav-brand">
      <p class="eyebrow">Short Circuit Company</p>
      <h2>Lighting CMS</h2>
    </div>
    <nav>
      <a href="dashboard.php" class="<?= ($activeNav ?? '') === 'dashboard' ? 'active' : '' ?>">Overview</a>
      <a href="articles.php" class="<?= ($activeNav ?? '') === 'articles' ? 'active' : '' ?>">Articles</a>
      <a href="standards.php" class="<?= ($activeNav ?? '') === 'standards' ? 'active' : '' ?>">Standards</a>
      <a href="standard_terms.php" class="<?= ($activeNav ?? '') === 'standard_terms' ? 'active' : '' ?>">Terminology Matrix</a>
      <a href="tools.php" class="<?= ($activeNav ?? '') === 'tools' ? 'active' : '' ?>">Tools</a>
      <a href="events.php" class="<?= ($activeNav ?? '') === 'events' ? 'active' : '' ?>">Events</a>
      <a href="topics.php" class="<?= ($activeNav ?? '') === 'topics' ? 'active' : '' ?>">Community Topics</a>
      <a href="users.php" class="<?= ($activeNav ?? '') === 'users' ? 'active' : '' ?>">Users</a>
      <a href="roles.php" class="<?= ($activeNav ?? '') === 'roles' ? 'active' : '' ?>">Roles & Permissions</a>
    </nav>
    <div class="admin-nav-foot">
      <p>Signed in as <strong><?= e(currentAdmin()['username']) ?></strong></p>
      <a href="logout.php" class="logout-link">Log out</a>
      <a href="../public/index.php" class="logout-link" target="_blank">View live site ↗</a>
    </div>
  </aside>
  <main class="admin-main">
    <h1><?= e($pageTitle ?? '') ?></h1>
