<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $stmt = db()->prepare('SELECT * FROM users WHERE name LIKE ? OR email LIKE ? ORDER BY created_at DESC');
    $like = '%' . $q . '%';
    $stmt->execute([$like, $like]);
} else {
    $stmt = db()->query('SELECT * FROM users ORDER BY created_at DESC');
}
$users = $stmt->fetchAll();

$pageTitle = 'Users';
$activeNav = 'users';
include __DIR__ . '/partials_header.php';
?>
<p class="page-sub">Every public account (clients, SC employees, and leaders). Change a role, mark a specific account as always-auto-publish, or deactivate/delete an account.</p>

<div class="toolbar" style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
  <form method="get" style="display:flex;gap:8px;">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search name or email" class="search-input">
    <button type="submit" class="btn-secondary">Search</button>
  </form>
  <a href="user_edit.php" class="btn-primary">+ New User</a>
</div>

<table class="admin-table">
  <thead>
    <tr><th>Name</th><th>Email</th><th>Role</th><th>Pre-approved</th><th>Active</th><th>Joined</th><th></th></tr>
  </thead>
  <tbody>
    <?php foreach ($users as $u): ?>
    <tr>
      <td><?= e($u['name']) ?></td>
      <td><?= e($u['email']) ?></td>
      <td><span class="pill"><?= e(roleLabel($u['role'])) ?></span></td>
      <td><?= $u['is_preapproved'] ? '<span class="badge-ok">Yes</span>' : '<span class="badge-off">No</span>' ?></td>
      <td><?= $u['is_active'] ? '<span class="badge-ok">Active</span>' : '<span class="badge-off">Disabled</span>' ?></td>
      <td><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
      <td class="row-actions">
        <a href="user_edit.php?id=<?= (int)$u['id'] ?>">Edit</a>
        <form method="post" action="user_delete.php" onsubmit="return confirm('Delete this user account? This cannot be undone.');">
          <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
          <input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
          <button type="submit" class="link-danger">Delete</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$users): ?>
    <tr><td colspan="7" class="empty-row">No users found.</td></tr>
    <?php endif; ?>
  </tbody>
</table>

<?php include __DIR__ . '/partials_footer.php'; ?>
