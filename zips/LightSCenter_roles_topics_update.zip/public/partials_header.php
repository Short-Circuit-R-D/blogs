<?php
/** @var string $pageTitle */
require_once __DIR__ . '/../includes/auth_user.php';
$navUser = currentUser();
$navUserFull = $navUser ? currentUserFull() : null;
$navCanModerate = $navUserFull && roleCan($navUserFull['role'], 'can_moderate_topics');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Lighting Technical Data') ?> — Short Circuit Company</title>
<link rel="stylesheet" href="assets/css/site.css">
</head>
<body>
<div class="header">
  <div class="header-inner">
    <div style="display:flex;align-items:center;gap:var(--space-xl);">
      <a href="index.php"><img src="https://shortcircuit.company/assets/img/logo-dark.svg" alt="Short Circuit Company" style="height:32px;width:auto;"></a>
      <nav class="main-nav">
        <a href="articles.php">Articles</a>
        <a href="topics.php">Community</a>
        <a href="search.php">Search</a>
        <?php if ($navCanModerate): ?><a href="moderate.php">Moderate</a><?php endif; ?>
      </nav>
    </div>
    <div style="display:flex;align-items:center;gap:var(--space-md);">
      <span class="header-tag">Lighting Standards · Technical Reference</span>
      <?php if ($navUser): ?>
        <a class="nav-account" href="account.php"><?= e($navUser['name']) ?></a>
      <?php else: ?>
        <a class="nav-account" href="login.php">Log In</a>
      <?php endif; ?>
      <button class="theme-btn" id="themeToggle">🌙 Dark</button>
    </div>
  </div>
</div>
