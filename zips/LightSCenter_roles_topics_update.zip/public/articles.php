<?php
require_once __DIR__ . '/../includes/auth_user.php';

$q     = trim($_GET['q'] ?? '');
$topic = trim($_GET['topic'] ?? '');
$page  = max(1, (int)($_GET['page'] ?? 1));
$result = paginateArticles($q, $page, 12, $topic);

$topics         = getArticleTopics();
$followedTopics = currentUser() ? getUserSubscribedTopics((int)currentUser()['id']) : [];

$pageTitle = 'All Articles';
include __DIR__ . '/partials_header.php';
?>

<div class="wrap hero" style="padding-bottom:0;">
  <p class="eyebrow">SC Lighting Standards</p>
  <h1 class="headline">All <span style="color:var(--sc-red);">Articles</span></h1>
  <p class="sub">Every lighting parameter, standard breakdown, and design guide in one place — searchable, and growing. Follow a topic's bell to get emailed when a new one on it goes live.</p>
  <div class="divider"></div>
</div>

<div class="wrap section" style="border-top:none;">

  <div class="search-panel">
    <form method="get" class="search-panel-form">
      <?php if ($topic !== ''): ?><input type="hidden" name="topic" value="<?= e($topic) ?>"><?php endif; ?>
      <div class="search-input-pill">
        <svg class="search-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M21 21l-4.3-4.3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search articles by keyword…" autofocus>
        <?php if ($q !== ''): ?><a class="search-clear-x" href="<?= e('articles.php' . ($topic !== '' ? '?topic=' . urlencode($topic) : '')) ?>" title="Clear search">✕</a><?php endif; ?>
      </div>
      <button type="submit" class="search-submit-btn">Search</button>
    </form>

    <?php
    $basePath = 'articles.php';
    include __DIR__ . '/partials_topic_chips.php';
    ?>
  </div>

  <?php if ($q !== '' || $topic !== ''): ?>
    <p class="search-meta">
      <?= (int)$result['total'] ?> result<?= $result['total'] === 1 ? '' : 's' ?>
      <?= $q !== '' ? ' for "' . e($q) . '"' : '' ?>
      <?= $topic !== '' ? ' in <strong>' . e($topic) . '</strong>' : '' ?>
      <a class="clear-search" href="articles.php">Clear all filters</a>
    </p>
  <?php endif; ?>

  <div class="article-grid">
    <?php foreach ($result['rows'] as $a): include __DIR__ . '/partials_article_card.php'; endforeach; ?>
    <?php if (!$result['rows']): ?><p class="empty-note">No articles matched. <a href="articles.php">Clear the search</a> to see everything.</p><?php endif; ?>
  </div>

  <?= renderPagination('articles.php', ['q' => $q, 'topic' => $topic], $result['page'], $result['totalPages']) ?>
</div>

<?php include __DIR__ . '/partials_footer.php'; ?>
