// Theme toggle
(function () {
  const btn = document.getElementById('themeToggle');
  const saved = localStorage.getItem('sc-theme');
  if (saved === 'dark') {
    document.body.classList.add('dark');
    if (btn) btn.textContent = '☀ Light';
  }
  if (btn) {
    btn.addEventListener('click', () => {
      const isDark = document.body.classList.toggle('dark');
      localStorage.setItem('sc-theme', isDark ? 'dark' : 'light');
      btn.textContent = isDark ? '☀ Light' : '🌙 Dark';
    });
  }
})();

// Generic carousel: pass a root element containing .carousel-track, .dots, prev/next buttons
function initCarousel(rootId) {
  const root = document.getElementById(rootId);
  if (!root) return;
  const track = root.querySelector('.carousel-track');
  const slides = Array.from(track.children);
  const dotsWrap = root.querySelector('.dots');
  const prevBtn = root.querySelector('.prev-slide');
  const nextBtn = root.querySelector('.next-slide');
  let index = 0;

  if (!slides.length) return;

  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'dot' + (i === 0 ? ' active' : '');
    dot.addEventListener('click', () => go(i));
    dotsWrap.appendChild(dot);
  });

  function go(i) {
    index = (i + slides.length) % slides.length;
    track.style.transform = `translateX(-${index * 100}%)`;
    dotsWrap.querySelectorAll('.dot').forEach((d, di) => d.classList.toggle('active', di === index));
  }

  if (prevBtn) prevBtn.addEventListener('click', () => go(index - 1));
  if (nextBtn) nextBtn.addEventListener('click', () => go(index + 1));
}

// Science block tabs (Physical Mechanism / Physiological Impact / Psychological Impact)
function initScienceTabs() {
  document.querySelectorAll('.science-block').forEach((block) => {
    const tabs = block.querySelectorAll('.sci-tab');
    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        const key = tab.getAttribute('data-sci-tab');
        block.querySelectorAll('.sci-tab').forEach((t) => t.classList.toggle('active', t === tab));
        block.querySelectorAll('.sci-panel').forEach((p) => p.classList.toggle('active', p.getAttribute('data-sci-panel') === key));
      });
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initCarousel('toolsCarousel');
  initCarousel('eventsCarousel');
  initScienceTabs();
});
