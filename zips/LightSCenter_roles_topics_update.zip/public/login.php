<?php
require_once __DIR__ . '/../includes/auth_user.php';

if (currentUser()) redirect('account.php');

$error = null;
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    userCsrfCheck();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT id, name, email, password_hash, is_active FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash']) && !$user['is_active']) {
        $error = 'This account has been deactivated. Contact a Short Circuit admin.';
    } elseif ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email']];
        $redirectTo = $_SESSION['post_login_redirect'] ?? 'index.php';
        unset($_SESSION['post_login_redirect']);
        redirect($redirectTo);
    } else {
        $error = 'Incorrect email or password.';
    }
}

$pageTitle = 'Log In';
include __DIR__ . '/partials_header.php';
?>
<div class="wrap section auth-section" style="border-top:none;">
  <div class="auth-card">
    <p class="eyebrow">Short Circuit Company</p>
    <h2 class="section-title">Log In</h2>
    <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="post" novalidate>
      <input type="hidden" name="csrf" value="<?= e(userCsrfToken()) ?>">
      <label>Email
        <input type="email" name="email" value="<?= e($email) ?>" required autofocus>
      </label>
      <label>Password
        <input type="password" name="password" required>
      </label>
      <button type="submit" class="auth-submit">Log In</button>
    </form>
    <p class="auth-switch">No account yet? <a href="register.php">Create one</a></p>
  </div>
</div>
<?php include __DIR__ . '/partials_footer.php'; ?>
