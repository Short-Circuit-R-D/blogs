<?php
require_once __DIR__ . '/../includes/auth_user.php';
require_once __DIR__ . '/../includes/mailer.php';

if (currentUser()) redirect('account.php');

$error = null;
$name = $email = '';
$subscribe = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    userCsrfCheck();
    $name      = trim($_POST['name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $subscribe = isset($_POST['subscribe']);

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Please fill in your name, email, and a password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'That email address doesn\'t look right.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'An account with that email already exists.';
        } else {
            $token = bin2hex(random_bytes(24));
            $stmt = db()->prepare('INSERT INTO users (name, email, password_hash, is_subscribed, unsubscribe_token) VALUES (?,?,?,?,?)');
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $subscribe ? 1 : 0, $token]);
            $userId = (int)db()->lastInsertId();

            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $userId, 'name' => $name, 'email' => $email];

            $body = '<p>Hi ' . e($name) . ',</p><p>Your account is ready. '
                  . ($subscribe ? 'You\'re subscribed to new-guide email alerts — turn this off any time from your account page.' : 'You can turn on new-guide email alerts any time from your account page.')
                  . '</p>';
            sendMail($email, 'Welcome to Short Circuit Lighting Standards', siteEmailLayout('Welcome', $body));

            redirect($_SESSION['post_login_redirect'] ?? 'index.php');
        }
    }
}

$pageTitle = 'Create Account';
include __DIR__ . '/partials_header.php';
?>
<div class="wrap section auth-section" style="border-top:none;">
  <div class="auth-card">
    <p class="eyebrow">Short Circuit Company</p>
    <h2 class="section-title">Create Account</h2>
    <p class="section-sub">Save no favorites yet — just a fast way to subscribe to new lighting guides by email.</p>
    <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="post" novalidate>
      <input type="hidden" name="csrf" value="<?= e(userCsrfToken()) ?>">
      <label>Name
        <input type="text" name="name" value="<?= e($name) ?>" required autofocus>
      </label>
      <label>Email
        <input type="email" name="email" value="<?= e($email) ?>" required>
      </label>
      <label>Password <span class="hint">(8+ characters)</span>
        <input type="password" name="password" minlength="8" required>
      </label>
      <label class="checkbox-row">
        <input type="checkbox" name="subscribe" <?= $subscribe ? 'checked' : '' ?>>
        <span>Email me when a new lighting guide is published</span>
      </label>
      <button type="submit" class="auth-submit">Create Account</button>
    </form>
    <p class="auth-switch">Already have an account? <a href="login.php">Log in</a></p>
  </div>
</div>
<?php include __DIR__ . '/partials_footer.php'; ?>
